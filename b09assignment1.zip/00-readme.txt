All files are also in 01-all-files.zip.

Handout and question: cscb09-2024-5-a1.html

Sample inputs and outputs: sample-*.txt. (See handout for descriptions.)
